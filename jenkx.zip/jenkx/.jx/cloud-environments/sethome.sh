#!/usr/bin/env bash

mkdir -p jxhome
export KUBECONFIG=jxhome/config
export JX_HOME=jxhome
