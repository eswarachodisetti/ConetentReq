# Thunder is projectX's production cloud environment

If you have not yet setup helm on your cluster then run this once:
```
make setup
```

Then to install run:

```
make install
```

Or import the Jenkinfile into Jenkins to enable CI/CD
