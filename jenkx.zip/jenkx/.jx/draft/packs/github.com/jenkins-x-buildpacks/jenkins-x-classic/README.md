# jenkins-x-classic
Classic Build Pack for libraries (CI + Release but no CD) for releasing Java, Maven, Gradle, NPM modules but without deploying on any specific cloud or infrastructure
